<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'infotech12');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '`,t@,cWG%y}Ht}su<]/(^/R-Of5>$>(iPoRVj36sf8GLqef:Nh41lH0|t2G9VMK1');
define('SECURE_AUTH_KEY',  'nLTgR,kMZ[/+<0-/~o?leP2Zqhr?-snb J>lG+4-)#4pQN$(h#02|D#f%Q#M7Zq%');
define('LOGGED_IN_KEY',    'xSa+9Wd1]W`!y&T}EOhi_(!hXr2}.,E3)6jb4e8O=24U$.!QUPe=(oTV7;Au+4&@');
define('NONCE_KEY',        'S|xq;)<1,7hW<{:w+.8@Q9/rDi)N]wm~cP,d~BN5)C(,;[?lik;s{yHJU~,Il,Y5');
define('AUTH_SALT',        '*n1F2Qh;+I2wfMui@mLcjI*+Mm[1KFZ`Xo1eD ])[VyQ2jU*Jx}O jN[kh&v/~Nt');
define('SECURE_AUTH_SALT', 'ukNfd5V%z^/`;qOw.oCX@mgzXd{RpL~UX^j=]Cj[R;e`2@2#i$F,+wwkLa!`4@&a');
define('LOGGED_IN_SALT',   'u1:M_0.v<_9MPFK9++t22W`[vN8,ubM_!nf?zX$7nC5u^0U_yF]miN;oSZB6u$}d');
define('NONCE_SALT',       'p_Wonead5L!+dQtPdRsSy|u00C^25]9-S$Js!K]KWzbyOcNBRd8li;#9}n0qCp-?');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
